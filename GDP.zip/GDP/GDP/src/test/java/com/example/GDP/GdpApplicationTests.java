package com.example.GDP;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GdpApplicationTests {

	@Test
	void contextLoads() {
	}

}
